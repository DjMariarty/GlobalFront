using GlobalFront.Core.Simulation;
using UnityEngine;

namespace GlobalFront.Client
{
    public sealed class PrototypeHud : MonoBehaviour
    {
        private FixedSimulationRunner _runner;
        private GUIStyle _titleStyle;
        private GUIStyle _bodyStyle;

        private void Awake()
        {
            _runner = GetComponent<FixedSimulationRunner>();
        }

        private void OnGUI()
        {
#if !UNITY_SERVER
            EnsureStyles();

            var area = new Rect(18f, 18f, 430f, 126f);
            GUI.Box(area, GUIContent.none);

            GUILayout.BeginArea(new Rect(32f, 28f, 405f, 108f));
            GUILayout.Label("GLOBAL FRONT — TECHNICAL FOUNDATION 0.1", _titleStyle);
            GUILayout.Space(5f);
            GUILayout.Label(
                $"Authoritative simulation contract: {SimulationConstants.ServerTickRate} Hz\n" +
                $"Prototype tick: {_runner.Tick}   Backlog: {_runner.BacklogMilliseconds:F1} ms\n" +
                "Camera: WASD / arrows / screen edge    Zoom: mouse wheel",
                _bodyStyle);
            GUILayout.EndArea();
#endif
        }

        private void EnsureStyles()
        {
            if (_titleStyle != null)
            {
                return;
            }

            _titleStyle = new GUIStyle(GUI.skin.label)
            {
                fontSize = 14,
                fontStyle = FontStyle.Bold,
                normal = { textColor = new Color(0.38f, 0.78f, 1f) }
            };

            _bodyStyle = new GUIStyle(GUI.skin.label)
            {
                fontSize = 12,
                normal = { textColor = Color.white }
            };
        }
    }
}
